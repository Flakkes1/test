// ==UserScript==
// @name         AutoTradeResources
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Automatically trade resources between cities in Grepolis
// @author       You
// @match        https://br128.grepolis.com/game/*
// @icon         https://www.google.com/s2/favicons?domain=grepolis.com
// @grant        none
// ==/UserScript==

const timer = (ms) => new Promise((res) => setTimeout(res, ms));

$.Observer(uw.GameEvents.game.load).subscribe(() => {
    setTimeout(async () => {
        await main();
    }, 1000);
});

async function main() {
    let target_id = 3213;
    const { models: towns } = uw.MM.getOnlyCollectionByName('Town');

        for (const town of towns) {
            const { id } = town.attributes;
            let data = {};
            await timer(1000);
            data.wood = 500;
            data.iron = 500;
            data.stone = 500;
            data.id = target_id;
            data.type = "trade";
            data.town_id = id; //uw.ITowns.getCurrentTown().id;
            data.nl_init = true;
            uw.gpAjax.ajaxPost('town_info', 'trade', data);
        }
    }