// ==UserScript==
// @name         Grepolympia Bot
// @version      2.1.3
// @description  Automatic grepolympia
// @match        http://*.grepolis.com/game/*
// @match        https://*.grepolis.com/game/*
// ==/UserScript==

var uw;
if (typeof unsafeWindow == 'undefined') {
    uw = window;
} else {
    uw = unsafeWindow;
}

var enableBonusBuy = true; //true if you want to buy the bonus, false if you don't want to
var ChoosenUnit = "fury"; // Replace with the unit you want to sacrifice, keep it inside ""
var UnitAmount = 1; // Replace with the amount of units you want to sacrifice, it varies depending on which unit
var townId = [3600, 11955]; // Replace with your town IDs

function startTraining(townId) {
    const data = {
        "model_url": "GrepolympiaAthlete",
        "action_name": "startTraining",
        "captcha": null,
        "arguments": {
            "unit_type": ChoosenUnit,
            "amount": UnitAmount
        },
        "town_id": townId,
        "nl_init": true
    };

    uw.gpAjax.ajaxPost("frontend_bridge", "execute", data, {
        success: function(response) {
            console.log(`Training started successfully for town ${townId}:`, response);
        }
    });
}

function bonusBuy() {
    if (enableBonusBuy) {
        const info = {
            "model_url": "GrepolympiaAthlete",
            "action_name": "buyBonus",
            "captcha": null,
            "arguments": {},
            "nl_init": true
        };

        uw.gpAjax.ajaxPost("frontend_bridge", "execute", info, {
            success: function(response) {
                console.log("Bonus bought successfully:", response);
            }
        });
    } else {
        console.log("Bonus buy is disabled.");
    }
}

function main() {
    for (let i = 0; i < townId.length; i++) {
        startTraining(townId[i]);
    }
}

setTimeout(function() {
    main();
    bonusBuy();
}, 10000);

setInterval(function() {
    main();
    bonusBuy();
}, 1800000);
