// ==UserScript==
// @name         BuyResourcesGold_BOTAO
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Buys resources from the market
// @author       Anonimo aka Sadam
// @match        https://*.grepolis.com/game/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=grepolis.com
// @grant        none
// ==/UserScript==

var uw;
if (typeof unsafeWindow == 'undefined') {
    uw = window;
} else {
    uw = unsafeWindow;
}

var isScriptRunning = false;
var requestInterval;
var selectedResourceType = ""; // Variable to store the currently selected resource type

function loadbutton() {
    // Create and position the wood button
    let icono1 = document.createElement("div");
    icono1.className = "btn_settings wood"; // Add "wood" class to the wood button
    icono1.style.width = "20px";
    icono1.style.height = "20px";
    icono1.style.top = "8px";
    icono1.style.right = "590px"; // Adjusted position to the left of the original button
    icono1.style.zIndex = "10000";
    icono1.style.backgroundImage = "url('https://wiki.pt.grepolis.com/images/d/df/Wood.png')";
    icono1.style.backgroundSize = "cover";
    icono1.style.border = "2px solid black";
    icono1.style.borderRadius = "50%";
    document.getElementById("ui_box").appendChild(icono1);
    $(icono1).click(function() { selectResourceType("wood"); }); // Add click event for wood button

    // Create and position the stone button
    let icono2 = document.createElement("div");
    icono2.className = "btn_settings stone"; // Add "stone" class to the stone button
    icono2.style.width = "20px";
    icono2.style.height = "20px";
    icono2.style.top = "8px";
    icono2.style.right = "560px"; // Adjusted position to the left of the first button
    icono2.style.zIndex = "10000";
    icono2.style.backgroundImage = "url('https://wiki.pt.grepolis.com/images/d/d4/Stone.png')";
    icono2.style.backgroundSize = "cover";
    icono2.style.border = "2px solid black";
    icono2.style.borderRadius = "50%";
    document.getElementById("ui_box").appendChild(icono2);
    $(icono2).click(function() { selectResourceType("stone"); }); // Add click event for stone button

    // Create and position the iron button
    let icono3 = document.createElement("div");
    icono3.className = "btn_settings iron"; // Add "iron" class to the iron button
    icono3.style.width = "20px";
    icono3.style.height = "20px";
    icono3.style.top = "8px";
    icono3.style.right = "530px"; // Adjusted position to the left of the second button
    icono3.style.zIndex = "10000";
    icono3.style.backgroundImage = "url('https://wiki.pt.grepolis.com/images/4/45/Iron.png')";
    icono3.style.backgroundSize = "cover";
    icono3.style.border = "2px solid black";
    icono3.style.borderRadius = "50%";
    document.getElementById("ui_box").appendChild(icono3);
    $(icono3).click(function() { selectResourceType("iron"); }); // Add click event for iron button

    // Create and position the original button
    let icono4 = document.createElement("div");
    icono4.id = "GMESetupLink";
    icono4.className = "btn_settings";
    icono4.style.width = "20px";
    icono4.style.height = "20px";
    icono4.style.top = "8px";
    icono4.style.right = "485px"; // Position the original button to the rightmost
    icono4.style.zIndex = "10000";
    icono4.style.backgroundColor = "red";
    icono4.style.border = "2px solid black";
    icono4.style.borderRadius = "50%";
    document.getElementById("ui_box").appendChild(icono4);
    $(icono4).click(function() { toggleScript(); }); // Add click event for the original button
}

function selectResourceType(resourceType) {
    selectedResourceType = resourceType;
    $(".btn_settings").css("border", "2px solid black"); // Reset border color for all buttons
    $(`.btn_settings.${resourceType}`).css("border", "2px solid green"); // Set border color for the selected button
}

function toggleScript() {
    if (selectedResourceType !== "") {
        if (isScriptRunning) {
            stopScript();
            $(".btn_settings").css("border", "2px solid black"); // Reset border color for all buttons
            $("#GMESetupLink").css("background-color", "red"); // Change original button color to red
        } else {
            startScript(selectedResourceType);
            $(".btn_settings").css("border", "2px solid black"); // Reset border color for all buttons
            $(`.btn_settings.${selectedResourceType}`).css("border", "2px solid green"); // Set border color for the selected button
            $("#GMESetupLink").css("background-color", "green"); // Change original button color to green
        }
    }
}

function startScript(resourceType) {
    isScriptRunning = true;

    $(document).ajaxSuccess(function(event, xhr, options) {
        if (options.url.includes('frontend_bridge') && options.data.includes('requestOffer')) {
            const response = JSON.parse(xhr.responseText);
            if (response && response.json && response.json.result === "success") {
                const mac = response.json.mac;
                const gold = response.json.offer.gold;
                const resourceAmount = response.json.offer.resource_amount;
                confirmOffer(mac, gold, resourceAmount, resourceType);
            }
        }
    });

    async function requestOffer(resourceType) {
        const gold = 25;
        let x;
        switch(resourceType) {
            case 'wood':
                x = Math.round(gold / 0.0148);
                break;
            case 'stone':
                x = Math.round(gold / 0.0165);
                break;
            case 'iron':
                x = Math.round(gold / 0.0153);
                break;
            default:
                x = 0;
                break;
        }
        const data = {
            "model_url": "PremiumExchange",
            "action_name": "requestOffer",
            "arguments": {
                "type": "buy",
                "gold": gold,
                [resourceType]: x
            },
            "nl_init": true
        };

        uw.gpAjax.ajaxPost('frontend_bridge', 'execute', data);
    }

    async function confirmOffer(mac, gold, resourceAmount, resourceType) {
        const data = {
            "model_url": "PremiumExchange",
            "action_name": "confirmOffer",
            "arguments": {
                "type": "buy",
                "gold": gold,
                "mac": mac,
                "offer_source": "main",
                [resourceType]: resourceAmount
            },
            "nl_init": true
        };

        uw.gpAjax.ajaxPost('frontend_bridge', 'execute', data);
    }

    // Start requesting offers
    requestInterval = setInterval(() => requestOffer(resourceType), 1000);
}

function stopScript() {
    isScriptRunning = false;
    clearInterval(requestInterval);
}

loadbutton(); // Call the loadbutton function to add the buttons to the page
