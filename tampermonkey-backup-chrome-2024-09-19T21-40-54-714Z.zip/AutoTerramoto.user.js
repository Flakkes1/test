// ==UserScript==
// @name         AutoTerramoto
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       Anonimo aka Sadam
// @match      http://*.grepolis.com/game/*
// @match      https://*.grepolis.com/game/*
// @grant        none
// ==/UserScript==

var uw;
if (typeof unsafeWindow == 'undefined') uw = window;
else uw = unsafeWindow;

const cast_spell_city = (town_id, favors) => {
    const data = {
        "model_url": "CastedPowers",
        "action_name": "cast",
        "arguments": {
            "power_id": "earthquake",
            "target_id": 5907
        },
        "town_id": town_id,
        "nl_init": true
    };
    uw.gpAjax.ajaxPost("frontend_bridge", "execute", data, function(response) {
        console.log("Spell casting response:", response);
    });
};

function main() {
    console.log("Script is running!");
    try {
        const town = uw.ITowns.getCurrentTown();
        if (!town) {
            return;
        }
        console.log("Current Town:", town);

        const { poseidon_favor } = uw.ITowns.player_gods.attributes;
        console.log("Current Poseidon Favor:", poseidon_favor);

        if (Object.keys(uw.ITowns.towns).length !== 1) {

            // try to cast spell when possible
            if (poseidon_favor >= 350) {
                console.log("Casting spell...");
                // Repeat the action every 200ms for 5 seconds
                const interval = setInterval(() => {
                    cast_spell_city(town.id);
                }, 200);
                setTimeout(() => {
                    clearInterval(interval);
                }, 5000);
            }
        }
    } catch (error) {
        console.error("Error:", error);
    }

    // Adjust the timing for every 3 hours (in milliseconds)
    setInterval(main, 1 * 60 * 60 * 1000); // 3 hours in milliseconds
}

function startScript() {
    console.log("Script is starting...");
    // Set the start time (10:00:00 AM)
    const now = new Date();
    const startHour = 16;
    const startMinute = 28;
    const startSecond = 15;
    let delay = ((startHour - now.getHours()) * 60 * 60 +
                 (startMinute - now.getMinutes()) * 60 +
                 (startSecond - now.getSeconds())) * 1000;

    // If the specified time has already passed for today, add 1 day to the delay
    if (delay < 0) {
        delay += 24 * 60 * 60 * 1000;
    }

    console.log(`Script will start running in ${delay / 1000} seconds`);

    setTimeout(main, delay);
}

// Initial Execution
startScript();