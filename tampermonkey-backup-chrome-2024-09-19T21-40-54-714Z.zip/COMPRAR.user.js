// ==UserScript==
// @name         COMPRAR
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Buys resources from the market
// @author       Anonimo aka Sadam
// @match        https://*.grepolis.com/game/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=grepolis.com
// @grant        none
// ==/UserScript==


var uw;
if (typeof unsafeWindow == 'undefined') {
    uw = window;
} else {
    uw = unsafeWindow;
}
(async function() {
    'use strict';

    let isWaitingForResponse = false;
    let maxDifferenceResource = ''; // Declare maxDifferenceResource globally
    let maxDifference = -Infinity; // Declare maxDifference globally
    let stockCapacityDifferences = {}; // Declare stockCapacityDifferences globally

    async function getMarket() {
        let data = {"model_url":"PremiumExchange","action_name":"read"};
        let req = await uw.gpAjax.ajaxGet("frontend_bridge", "execute", data);
        return JSON.parse(req);
    }

    async function calculateStockCapacityDifference() {
        try {
            const marketData = await getMarket();

            for (const resource in marketData.json) {
                if (resource !== 't_token' && resource !== 'notifications' && resource !== 'next_fetch_in') {
                    const stock = marketData.json[resource].stock;
                    const capacity = marketData.json[resource].capacity;
                    const difference = capacity - stock;
                    stockCapacityDifferences[resource] = difference;

                    // Update maxDifference if the current difference is greater
                    if (difference > maxDifference) {
                        maxDifference = difference;
                        maxDifferenceResource = resource;
                    }
                }
            }
        } catch (error) {
            console.error("Error fetching market data:", error);
        }
    }

    async function requestOffer() {
        if (isWaitingForResponse) return; // Check if we're already waiting for a response to avoid overlapping calls
        isWaitingForResponse = true; // Set the flag when making a new request

        await calculateStockCapacityDifference(); // Calculate differences between stock and capacity

        // Check if any resource has difference greater than 500
        let hasDifferenceGreaterThan500 = Object.values(stockCapacityDifferences).some(difference => difference > 500);

        if (hasDifferenceGreaterThan500) {
            const x = Math.round(maxDifference * 0.0148 * 0.9); // Calculate gold based on the maximum difference
            const data = {
                "model_url": "PremiumExchange",
                "action_name": "requestOffer",
                "arguments": {
                    "type": "sell",
                    "gold": x,
                    [maxDifferenceResource]: maxDifference // Substitute the resource with the biggest difference
                },
                "nl_init": true
            };

            uw.gpAjax.ajaxPost('frontend_bridge', 'execute', data);
        }

        isWaitingForResponse = false; // Reset the flag
    }

    $(document).ajaxSuccess(function(event, xhr, options) {
        if (options.url.includes('frontend_bridge') && options.data.includes('requestOffer')) {
            const response = JSON.parse(xhr.responseText);
            if (response && response.json && response.json.result === "success") {
                const mac = response.json.mac;
                const gold = response.json.offer.gold;
                const amount = response.json.offer.resource_amount;
                confirmOffer(mac, gold, amount);
            }
        }
    });

    async function confirmOffer(mac, gold, amount) {
        const data = {
            "model_url": "PremiumExchange",
            "action_name": "confirmOffer",
            "arguments": {
                "type": "sell",
                "gold": gold,
                "mac": mac,
                "offer_source": "main",
                [maxDifferenceResource]: amount // Substitute the resource with the biggest difference
            },
            "nl_init": true
        };

        uw.gpAjax.ajaxPost('frontend_bridge', 'execute', data);
    }

    setInterval(requestOffer, 5000); // Attempt to request an offer every second
})();
