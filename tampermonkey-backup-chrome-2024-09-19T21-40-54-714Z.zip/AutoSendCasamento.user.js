// ==UserScript==
// @name         AutoSendCasamento
// @namespace    http://tampermonkey.net/
// @version      0.2
// @description  try to take over the world!
// @author       Anonimo aka Sadam
// @match        https://*.grepolis.com/game/*
// @grant        none
// ==/UserScript==

var uw;
if (typeof unsafeWindow == 'undefined') uw = window;
else uw = unsafeWindow;

var scriptRunning = false;
var targetId = 0000; // Default target_id

const cast_spell_city = (town_id) => {
    const data = {
        "model_url": "CastedPowers",
        "action_name": "cast",
        "arguments": {
            "power_id": "wedding",
            "target_id": targetId // Use the updated targetId
        },
        "town_id": town_id,
        "nl_init": true
    };
    uw.gpAjax.ajaxPost("frontend_bridge", "execute", data, function(response) {
        console.log("Spell casting response:", response);
    });
};

function createInterface() {
    const container = document.createElement('div');
    container.id = 'customInterface';
    container.style = 'position: fixed; top: -4px; left: 500px; background: transparent; padding: 10px; z-index: 1000;';

    const input = document.createElement('input');
    input.id = 'customInput';
    input.type = 'text';
    input.placeholder = 'Enter target ID';
    input.style = 'width: 150px; margin-right: 10px;';

    const submitButton = document.createElement('button');
    submitButton.innerText = 'Submit';
    submitButton.onclick = function() {
        const inputValue = document.getElementById('customInput').value;
        targetId = parseInt(inputValue, 10); // Update targetId with the new value
        if (isNaN(targetId)) {
            console.error('Invalid target ID');
            alert('Please enter a valid number for target ID.');
        } else {
            console.log('Target ID updated to:', targetId);
        }
    };

    const toggleButton = document.createElement('button');
    toggleButton.innerText = 'Start';
    toggleButton.onclick = function() {
        scriptRunning = !scriptRunning;
        if (scriptRunning) {
            toggleButton.innerText = 'Stop';
            startScript();
        } else {
            toggleButton.innerText = 'Start';
            stopScript();
        }
    };

    container.appendChild(input);
    container.appendChild(submitButton);
    container.appendChild(toggleButton);
    document.body.appendChild(container);
}

function main() {
    if (!scriptRunning) return;
    try {
        const town = uw.ITowns.getCurrentTown();
        if (!town) {
            return;
        }
        console.log("Current Town:", town);

        const { hera_favor } = uw.ITowns.player_gods.attributes;

        if (Object.keys(uw.ITowns.towns).length === 1) {
            if (hera_favor >= 30) {
                console.log("Casting spell...");
                cast_spell_city(town.id);
                setTimeout(main, 10000);
            } else {
                const data = {
                    "folder_id":0,
                    "filter_type":"all",
                    "town_id": town.id,
                    "nl_init":true
                };
                uw.gpAjax.ajaxPost("report", "delete_all_from_folder", data)
            }
        }
 } catch (error) {
        console.error("Error:", error);
    }
    setTimeout(main, 1000); // Adjust as needed
}

function startScript() {
    scriptRunning = true;
    main();
    console.log("Script started.");
}

function stopScript() {
    scriptRunning = false;
    console.log("Script stopped.");
}

// Initial UI setup
createInterface();