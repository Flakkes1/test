// ==UserScript==
// @name         AutoSendBiga
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match      http://*.grepolis.com/game/*
// @match      https://*.grepolis.com/game/*
// @grant        none
// ==/UserScript==

var uw;
if (typeof unsafeWindow == 'undefined') uw = window;
else uw = unsafeWindow;

const cast_spell_city = (town_id, favors) => {
    const data = {
        "model_url": "CastedPowers",
        "action_name": "cast",
        "arguments": {
            "power_id": "divine_sign",
            "target_id": 71
        },
        "town_id": town_id,
        "nl_init": true
    };
    uw.gpAjax.ajaxPost("frontend_bridge", "execute", data, function(response) {
        console.log("Spell casting response:", response);
    });
};

function main() {
    try {
        const town = uw.ITowns.getCurrentTown();
        if (!town) {
            return;
        }
        console.log("Current Town:", town);

        const { zeus_favor } = uw.ITowns.player_gods.attributes;

        if (Object.keys(uw.ITowns.towns).length === 1) {  // Change === to !== if the account has more than one city

            // try to cast spell when possible
            if (zeus_favor >= 50) {
                console.log("Casting spell...");
                cast_spell_city(town.id);
                setTimeout(main, 1000);
            }
            else{
                const data = {
                    "folder_id":0,
                    "filter_type":"all",
                    "town_id": town.id,
                    "nl_init":true
                };
                uw.gpAjax.ajaxPost("report", "delete_all_from_folder", data)
            }
        }
    } catch (error) {
        console.error("Error:", error);
    }

    // Adjust the timing if needed
    setTimeout(main, 7000);
}

// Initial Execution
setTimeout(main, 7000);