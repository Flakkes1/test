// ==UserScript==
// @name        MarketGoldTransfer
// @description Vende Recursos
// @author      Anonimo aka Sadam
// @version     1.0.0
// @match       https://*.grepolis.com/game/*
// ==/UserScript==

(function() {
    'use strict';
    const threshold = 500;

    // Call market endpoint and return resources
    async function getMarket() {
        let data = {"model_url":"PremiumExchange","action_name":"read"};
        let req = await gpAjax.ajaxGet("frontend_bridge", "execute", data);
        return JSON.parse(req);
    }

    // Check if a resource is missing or low
    function isResourceMissing(resource) {
        return resource.stock + threshold < resource.capacity;
    }

    // Function to sell the max amount of a resource
    async function sellResource(resource) {
        const { models: towns } = uw.MM.getOnlyCollectionByName('Town');

        for (const town of towns) {
            const { id } = town.attributes;
        let data = {
            "model_url": "PremiumExchange",
            "action_name": "requestOffer",
            "arguments":{"type":"sell","gold":1, "stone":100},"town_id":id, "nl_init":true}
        await gpAjax.ajaxPost("frontend_bridge", "execute", data);

        let data2 = {
            "model_url": "PremiumExchange",
            "action_name": "confirmOffer",
            "arguments":{"type":"sell","gold":1, "stone":100},"town_id":id, "nl_init":true}
        await gpAjax.ajaxPost("frontend_bridge", "execute", data2);
    }
    }

    // Main function to check resources and sell if necessary
    async function main() {
        let data = await getMarket();
        let market = false;
        if (isResourceMissing(data.json.iron)) {
            market = true;
            await sellResource(data.json.iron);
        }
        if (isResourceMissing(data.json.stone)) {
            market = true;
            await sellResource(data.json.stone);
        }
        if (isResourceMissing(data.json.wood)) {
            market = true;
            await sellResource(data.json.wood);
        }
        if (market) {
            console.log("Resources sold successfully.");
        } else {
            console.log("No resources need to be sold.");
        }
    }

    // Set up interval to run the main function every 10 seconds
    let loop = setInterval(main, 10000);

})();