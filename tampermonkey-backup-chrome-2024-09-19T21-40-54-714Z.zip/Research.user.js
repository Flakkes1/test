// ==UserScript==
// @name         Research
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Anonimo is the biggest cheater ever!
// @author       Anonimo aka sadam
// @include      http://*.grepolis.com/game/*
// @include      https://*.grepolis.com/game/*
// @grant        none
// ==/UserScript==

const timer = (ms) => new Promise((res) => setTimeout(res, ms));

setTimeout(async() => {
    await main();

    setInterval(async() => {
        await main()
    },20000);
}, 7000);


let req = {slinger:1,archer:1,town_guard:1,
           hoplite:4,meteorology:4,
           espionage:7,booty:7,pottery:7,
           architecture:10,rider:10,instructor:10,
           bireme:13,building_crane:13,shipwright:13,colonize_ship:13,
           chariot:16,attack_ship:16,conscription:16,
           demolition_ship:19,catapult:19,cryptography:19,democracy:19,
           small_transporter:22,plow:22,berth:22,
           trireme:25,phalanx:25,breach:25,mathematics:25,
           ram:28,cartography:28,take_over:28,
           stone_storm:31,temple_looting:31,divine_selection:31,
           combat_experience:34,strong_wine:34,set_sail:34
          }



let model = {slinger:false,
             archer:false,
             town_guard:false,
             hoplite:false,
             meteorology:false,
             espionage:false,
             booty:true,
             pottery:true,
             rider:false,
             architecture:true,
             instructor:false,
             bireme:false,
             building_crane:true,
             shipwright:true,
             colonize_ship:true,
             chariot:false,
             attack_ship:false,
             conscription:false,
             demolition_ship:false,
             catapult:false,
             cryptography:false,
             democracy:false,
             small_transporter:false,
             plow:true,
             berth:false,
             trireme:false,
             phalanx:false,
             breach:false,
             mathematics:true,
             ram:false,
             cartography:true,
             take_over:true,
             stone_storm:false,
             temple_looting:false,
             divine_selection:false,
             combat_experience:true,
             strong_wine:true,
             set_sail:true,
             diplomacy:false
            }


async function main(){
    let towns = uw.MM.getOnlyCollectionByName('Town').models; //saca todas as cidades7
    console.log(towns);
    for (const town of towns){ //percorre as cidades -> town fica com imensas merdas (mete ITowns.getCurrentTown() na consola para ver
        let townId = town.id;
        const researches = town.getResearches().attributes;
        const academyLvl = town.getBuildings().attributes.academy;
        for (const [id, value] of Object.entries(researches)){
            if (id == 'diplomacy' || id == 'id') continue;
            if (model[id] != value && academyLvl >= req[id] && model[id]){

                let data = {};
                data.model_url = "ResearchOrder";
                data.action_name = "research";
                data.arguments = {id};
                data.town_id = townId;
                data.nl_init = true;
                uw.gpAjax.ajaxPost('frontend_bridge', 'execute', data);
                await timer(1500);
            }

        }


    }

}