// ==UserScript==
// @name         Recruiter NCs(Celebrations)
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Recruits NCs only if party and theater are already ongoing
// @author       Anonimo aka sadam
// @match        http://*.grepolis.com/game/*
// @match        https://*.grepolis.com/game/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Check if unsafeWindow is defined and assign to uw variable
    const uw = typeof unsafeWindow === 'undefined' ? window : unsafeWindow;

    // Function to get town IDs with ongoing celebrations by type ('party', 'theater')
    const getCelebrationsList = type => {
        const celebrationModels = uw.MM.getModels().Celebration;
        if (typeof celebrationModels === 'undefined') return [];
        return Object.values(celebrationModels)
            .filter(celebration => celebration.attributes.celebration_type === type)
            .map(triumph => triumph.attributes.town_id);
    };

    // Main function to recruit units in towns
    async function main() {
        try {
            // Get all towns
            const towns = uw.MM.getOnlyCollectionByName('Town').models;

            // Get the list of towns that are already celebrating 'party' and 'theater'
            const partyTowns = getCelebrationsList('party');
            const theaterTowns = getCelebrationsList('theater');

            // Function to calculate recruitment capability for colonize_ship
            function calculateRecruitmentCapability(townId) {
                const resources = uw.ITowns.getTown(townId).resources();
                const discount = uw.GeneralModifications.getUnitBuildResourcesModification(townId, uw.GameData.units['colonize_ship']);
                const { wood, stone, iron } = uw.GameData.units['colonize_ship'].resources;
                const favor = uw.GameData.units['colonize_ship'].favor;
                const w = resources.wood / Math.round(wood * discount);
                const s = resources.stone / Math.round(stone * discount);
                const i = resources.iron / Math.round(iron * discount);
                const f = resources.favor / favor;

                /* Calculate the maximum number of colonize_ship that can be built based on available resources */
                const max_w = Math.floor(w);
                const max_s = Math.floor(s);
                const max_i = Math.floor(i);
                const max_f = Math.floor(f);
                const max_possible = Math.min(max_w, max_s, max_i, max_f);

                /* Check for free population */
                const duable_with_pop = Math.floor(resources.population / uw.GameData.units['colonize_ship'].population); // for each troop

                return {
                    max_possible,
                    max_population: Math.floor(duable_with_pop * 170) // Max population for available troops
                };
            }

            // Object to store town IDs with number of colonize_ship to recruit
            const recruitmentData = {};

            // Loop through each town
            for (const town of towns) {
                // Extract town id
                const townId = town.id;

                // Check if the town is celebrating both 'party' and 'theater'
                if (!partyTowns.includes(townId) || !theaterTowns.includes(townId)) {
                    // Skip this town if it's not running both celebrations
                    continue;
                }

                // Calculate recruitment capability for colonize_ship
                const recruitmentCapability = calculateRecruitmentCapability(townId);

                // Check if the town can afford to build colonize_ship and has enough population for them
                if (recruitmentCapability.max_possible > 0 && recruitmentCapability.max_population > 0) {
                    // Add town ID with number of colonize_ship to recruit to the object
                    recruitmentData[townId] = {
                        colonize_ship: recruitmentCapability.max_possible // recruit maximum possible colonize_ship
                    };
                }
            }

            // Create data object with town IDs and number of colonize_ship to recruit
            const data = {
                "towns": recruitmentData,
                "nl_init": true
            };

            // Send ajax request to recruit units in towns
            await uw.gpAjax.ajaxPost('town_overviews', 'recruit_units', data);

        } catch (error) {
            console.error('Error in main function:', error);
        }
    }

    // Delay execution of main function
    setTimeout(main, 10000);
    setInterval(main, 31 * 60 * 1000);
})();
