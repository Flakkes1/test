// ==UserScript==
// @name         RuralManager
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Automate management of rural areas in the game.
// @author       Anonimo aka Sadam
// @match        https://*.grepolis.com/game/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const desiredLevel = 6; // Set your desired rural level here

    // Helper function to safely log
    const safeLog = (message) => {
        if (typeof console !== 'undefined') {
            console.log(message);
        }
    };

    const generateList = () => {
        let islandsList = [];
        let polisList = [];
        let townList = uw.MM.getOnlyCollectionByName('Town').models;

        for (let town of townList) {
            if (town.attributes.on_small_island) continue;
            let { island_id, id } = town.attributes;
            if (!islandsList.includes(island_id)) {
                islandsList.push(island_id);
                polisList.push(id);
            }
        }
        return polisList;
    };

    const main = async () => {
        let playerRelationModels = uw.MM.getOnlyCollectionByName('FarmTownPlayerRelation').models;
        let farmTownModels = uw.MM.getOnlyCollectionByName('FarmTown').models;
        let killpoints = uw.MM.getModelByNameAndPlayerId('PlayerKillpoints').attributes;

        const locked = playerRelationModels.filter(model => model.attributes.relation_status === 0);
        let available = killpoints.att + killpoints.def - killpoints.used;
        let unlocked = playerRelationModels.length - locked.length;

        if (locked.length > 0) {
            const discounts = [2, 8, 10, 30, 50, 100];
            if (unlocked < discounts.length && available < discounts[unlocked]) return;
            else if (available < 100) return;

            let towns = generateList();
            for (let town_id of towns) {
                let town = uw.ITowns.towns[town_id];
                let x = town.getIslandCoordinateX(),
                    y = town.getIslandCoordinateY();

                for (let farmtown of farmTownModels) {
                    if (farmtown.attributes.island_x != x || farmtown.attributes.island_y != y) continue;

                    for (let relation of locked) {
                        if (farmtown.attributes.id != relation.attributes.farm_town_id) continue;
                        unlockRural(town_id, relation.attributes.farm_town_id, relation.id);
                        safeLog(`Island ${farmtown.attributes.island_xy}: unlocked ${farmtown.attributes.name}`);
                        return;
                    }
                }
            }
        } else {
            let towns = generateList();
            const levelCosts = [1, 5, 25, 50, 100];
            for (let level = 1; level <= desiredLevel; level++) {
                if (available < levelCosts[level - 1]) return;

                for (let town_id of towns) {
                    let town = uw.ITowns.towns[town_id];
                    let x = town.getIslandCoordinateX();
                    let y = town.getIslandCoordinateY();

                    for (let farmtown of farmTownModels) {
                        if (farmtown.attributes.island_x != x || farmtown.attributes.island_y != y) continue;

                        for (let relation of playerRelationModels) {
                            if (farmtown.attributes.id != relation.attributes.farm_town_id) continue;
                            if (relation.attributes.expansion_stage >= desiredLevel) return; // Skip if town is already at max level
                            upgradeRural(town_id, relation.attributes.farm_town_id, relation.id);
                            safeLog(`Island ${farmtown.attributes.island_xy}: upgraded ${farmtown.attributes.name}`);
                            return;
                        }
                    }
                }
            }
        }
    };

    const unlockRural = (town_id, farm_town_id, relation_id) => {
        let data = {
            model_url: `FarmTownPlayerRelation/${relation_id}`,
            action_name: 'unlock',
            arguments: { farm_town_id: farm_town_id },
            town_id: town_id,
        };
        uw.gpAjax.ajaxPost('frontend_bridge', 'execute', data);
    };

    const upgradeRural = (town_id, farm_town_id, relation_id) => {
        let data = {
            model_url: `FarmTownPlayerRelation/${relation_id}`,
            action_name: 'upgrade',
            arguments: { farm_town_id: farm_town_id },
            town_id: town_id,
        };
        uw.gpAjax.ajaxPost('frontend_bridge', 'execute', data);
    };

    // Start the script 10 seconds after the page loads, then run every 20 minutes
    setTimeout(() => {
        main();
        setInterval(main, 3000); // 1200000 milliseconds = 20 minutes
    }, 5000);
})();
