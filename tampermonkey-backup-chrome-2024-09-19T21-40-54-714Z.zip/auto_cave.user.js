// ==UserScript==
// @name         auto_cave
// @author       anonimous
// @description  auto_cave
// @include      http://*.grepolis.com/game/*
// @include      https://*.grepolis.com/game/*
// ==/UserScript==



setInterval(function() {
    let store_percentage = 0.2;
    let islands_list = [];
    let polis_list = [];
    let rand = getRandomInt(400);

    let town_list = uw.MM.getOnlyCollectionByName('Town').models;
    for (let town of town_list) {

        let { island_id, id } = town.attributes;
        islands_list.push(island_id);
        polis_list.push(id);
    }
    let total = {
        wood: 0,
        stone: 0,
        iron: 0,
        storage: 0,
    };

    for (let town_id of polis_list) {
        let random_Store = getRandomInt(5) / 100;
        const town = uw.ITowns.getTown(town_id);
        let caveLvl = ITowns.towns[town_id].buildings().attributes.hide;
        if(caveLvl != 10) continue;
        const { wood, stone, iron, storage } = town.resources();
        let quantity = store_percentage * storage - (store_percentage * storage) * random_Store;
        if( iron>=(storage*0.9)){
            var request = {"model_url":"BuildingHide","action_name":"storeIron","arguments":{"iron_to_store": Math.round(quantity)},"town_id":town_id,"nl_init":true};
            setTimeout(store(request),300+rand);

        }
    }

},4000);

function store(request) {
    uw.gpAjax.ajaxPost('frontend_bridge', 'execute', request);
}

function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}


