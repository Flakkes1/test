// ==UserScript==
// @name         AutoSentinel
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Sends a sentinel to every town
// @author       Anonimo aka Sadam
// @include      http://*.grepolis.com/game/*
// @include      https://*.grepolis.com/game/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=grepolis.com
// @grant        none
// ==/UserScript==

var uw;
if (typeof unsafeWindow == 'undefined') {
    uw = window;
} else {
    uw = unsafeWindow;
}


async function main() {
    let repeat = true;
    while (repeat) {
    repeat = false;
    const { models: towns } = uw.ITowns.getTowns(2258870);
    let arrival_id = uw.ITowns.getTowns(2258870);
    if (uw.ITowns.towns[2779].units().bireme == null) continue;
    repeat = true;
    const data = {
        "bireme": 1,
        "id": arrival_id,
        "town_id": 2779,
        "type": "support",
        "nl_init": true
    }

uw.gpAjax.ajaxPost('town_info', 'send_units', data)
}
}
setInterval(main, 10000)