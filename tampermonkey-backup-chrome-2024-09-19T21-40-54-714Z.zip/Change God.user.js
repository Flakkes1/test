// ==UserScript==
// @name         Change God
// @version      2.1.3
// @description  Automatic event
// @author       Anonimo aka Sadam
// @match        http://*.grepolis.com/game/*
// @match        https://*.grepolis.com/game/*
// ==/UserScript==

var uw;
if (typeof unsafeWindow == 'undefined') {
    uw = window;
} else {
    uw = unsafeWindow;
}

function main() {
    const data = {"god_id":"hades","nl_init": true};
    uw.gpAjax.ajaxPost('building_temple', 'change_god', data);
}


setTimeout(main, 5000)