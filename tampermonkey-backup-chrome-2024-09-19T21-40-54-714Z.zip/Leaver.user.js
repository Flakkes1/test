// ==UserScript==
// @name         Leaver
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Leaves the alliance
// @author       Anonimo aka Sadam
// @match        https://pt101.grepolis.com/game/*
// @grant        none
// ==/UserScript==

var uw;
if (typeof unsafeWindow == 'undefined') {
    uw = window;
} else {
    uw = unsafeWindow;
}

async function Leave() {
    const data = {
        "nl_init":true
    }

uw.gpAjax.ajaxPost('alliance', 'leave', data);
}

function startScript() {
    const now = new Date();
    const startHour = 23;
    const startMinute = 55;
    const startSecond = 0;
    let delay = ((startHour - now.getHours()) * 60 * 60 +
                 (startMinute - now.getMinutes()) * 60 +
                 (startSecond - now.getSeconds())) * 1000;

    if (delay < 0) {
        delay += 24 * 60 * 60 * 1000;
    }

    setTimeout(Leave, delay);
}

startScript();