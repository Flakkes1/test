// ==UserScript==
// @name         SpartaAssassins Bot
// @version      2.1.3
// @description  Automatic event
// @author       Anonimo aka Sadam
// @match        http://*.grepolis.com/game/*
// @match        https://*.grepolis.com/game/*
// ==/UserScript==

var uw;
if (typeof unsafeWindow == 'undefined') {
    uw = window;
} else {
    uw = unsafeWindow;
}

function main(spot_id) {
    const data = {
        "model_url": "AssassinsPlayerSpot",
        "action_name": "fight",
        "captcha": null,
        "arguments": {
            "spot_id": spot_id
        },
        "nl_init": true
    };

    uw.gpAjax.ajaxPost("frontend_bridge", "execute", data, {
        success: function(response) {
            console.log("Successfully fought at spot_id: " + spot_id);
        },
        error: function(error) {
            console.error("Error fighting at spot_id: " + spot_id, error);
        }
    });
}

function refetchData() {
    const flecha = {
        "collections": {
            "AssassinsPlayerSpots": "[]"
        },
        "nl_init": true
    };

    uw.gpAjax.ajaxPost("frontend_bridge", "refetch", flecha, {
        success: function(response) {
            console.log("Refetched data successfully.");
        },
        error: function(error) {
            console.error("Error refetching data.", error);
        }
    });
}

function iterate() {
    for (let i = 0; i < 15; i++) {
        setTimeout(function() {
            main(i + 1);
            refetchData();
        }, i * 1000); // 1 second delay between each
    }
}

// Run the script when the page loads
window.addEventListener('load', function() {
    iterate();
});
