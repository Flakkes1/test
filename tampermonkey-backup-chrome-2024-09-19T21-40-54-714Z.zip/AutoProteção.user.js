// ==UserScript==
// @name         AutoProteção
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match      http://pt101.grepolis.com/game/*
// @match      https://pt101.grepolis.com/game/*
// @grant        none
// ==/UserScript==

var uw;
if (typeof unsafeWindow == 'undefined') uw = window;
else uw = unsafeWindow;

const cast_spell_city = (town_id, favors) => {
    const data = {
        "model_url": "CastedPowers",
        "action_name": "cast",
        "arguments": {
            "power_id": "town_protection",
            "target_id": 1
        },
        "town_id": town_id,
        "nl_init": true
    };
    uw.gpAjax.ajaxPost("frontend_bridge", "execute", data, function(response) {
        console.log("Spell casting response:", response);
    });
};

function main() {
    console.log("Script is running!");
    try {
        const town = uw.ITowns.getCurrentTown();
        if (!town) {
            return;
        }
        console.log("Current Town:", town);

        const { athena_favor } = uw.ITowns.player_gods.attributes;
        console.log("Current Athena Favor:", athena_favor);

        if (Object.keys(uw.ITowns.towns).length !== 1) {

            // try to cast spell when possible
            if (athena_favor >= 130) {
                console.log("Casting spell...");
                // Repeat the action every 200ms for 5 seconds
                const interval = setInterval(() => {
                    cast_spell_city(town.id);
                }, 200);
                setTimeout(() => {
                    clearInterval(interval);
                }, 5000);
            }
        }
    } catch (error) {
        console.error("Error:", error);
    }

    // Adjust the timing for every 3 hours (in milliseconds)
    setInterval(main, 3 * 60 * 60 * 1000); // 3 hours in milliseconds
}

function startScript() {
    console.log("Script is starting...");
    // Set the start time (10:00:00 AM)
    const now = new Date();
    const startHour = 20;
    const startMinute = 0;
    const startSecond = 0;
    let delay = ((startHour - now.getHours()) * 60 * 60 +
                 (startMinute - now.getMinutes()) * 60 +
                 (startSecond - now.getSeconds())) * 1000;

    // If the specified time has already passed for today, add 1 day to the delay
    if (delay < 0) {
        delay += 24 * 60 * 60 * 1000;
    }

    console.log(`Script will start running in ${delay / 1000} seconds`);

    setTimeout(main, delay);
}

// Initial Execution
startScript();