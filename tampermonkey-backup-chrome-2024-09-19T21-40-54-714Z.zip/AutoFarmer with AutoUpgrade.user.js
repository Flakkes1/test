// ==UserScript==
// @name         AutoFarmer with AutoUpgrade
// @author       Anonimo aka Sadam
// @description  Claims the resources to the town with the least resources and upgrades the villages to the desired level
// @version      2.1.3
// @match        http://*.grepolis.com/game/*
// @match        https://*.grepolis.com/game/*
// ==/UserScript==

(function () {
    'use strict';
    const uw = unsafeWindow ? unsafeWindow : window;

    var VillageDesiredLvl = 6

    /* Define cost and variables */
    const time = 610000; //620000; time in seconds - 10 min + some extra
    const delta_time = 10000;
    let loop, lastTime, timer;
    let startOnLogin = true;

    const buttonHtml =
        '<div class="divider"></div><div class="activity" id="btbutton" style="filter: brightness(70%) sepia(100%) hue-rotate(-50deg) saturate(1000%) contrast(0.8);"><p id="ptimer" style="z-index: 6; top: -8px; position: relative; font-weight: bold;"></p></div>';

    /* Farm Town Upgrade Logic */
    async function startUpgrading() {
        const freeze = delay => new Promise(resolve => setTimeout(resolve, delay));
        const farmTownsPlayerRelations = Object.values(uw.MM.getModels().FarmTownPlayerRelation)
            .filter(ftpr => (
                ftpr.getExpansionStage() < VillageDesiredLvl - 1 ||
                (
                    ftpr.getExpansionStage() === VillageDesiredLvl - 1 &&
                    !ftpr.isUpgradeRunning()
                )
            ));
        let count = farmTownsPlayerRelations.length;
        for (const ftpr of farmTownsPlayerRelations) {
            if (ftpr.isLocked()) await freeze(1000, 5000).then(() => ftpr.unlock());
            else if (!ftpr.isUpgradeRunning()) await freeze(5000, 10000).then(() => ftpr.upgrade());
            ftpr.onLevelChange(ftpr, () => {
                if (ftpr.getExpansionStage() < VillageDesiredLvl) return ftpr.upgrade();
                if ((count--) === 0) console.log("All farm towns have been upgraded");
            });
        }
    }

    /* Scheduler for Upgrades */
    function scheduleUpgrades() {
        let hourMillis = 3600000; // 1 hour in milliseconds
        let randomDelay = Math.floor(Math.random() * 600000); // up to 10 minutes in milliseconds
        setTimeout(() => {
            startUpgrading();
            scheduleUpgrades(); // Reschedule after completion
        }, hourMillis + randomDelay);
    }

    /* Existing AutoFarm Logic */
    function claim(polisList) {
        let data = {
            towns: polisList,
            time_option_base: 300,
            time_option_booty: 600,
            claim_factor: 'normal',
        };
        uw.gpAjax.ajaxPost('farm_town_overviews', 'claim_loads_multiple', data);
    }

    function generateList() {
        let towns = uw.MM.getOnlyCollectionByName('Town').models;
        let islandTownsMap = new Map();

        towns.forEach(town => {
            if (town.attributes.on_small_island) return;

            let islandID = town.attributes.island_id;
            let resources = town.attributes.resources;
            let storage = town.attributes.storage;

            // Calculate the total amount of all resources
            let totalResources = resources.wood + resources.stone + resources.iron;

            // Calculate the total storage capacity for all resources combined (assuming 3 resources)
            let totalStorageCapacity = storage * 3;

            // Calculate the percentage of storage capacity filled
            let percentageFilled = (totalResources / totalStorageCapacity) * 100;

            // Skip if the town's storage is completely full
            if (percentageFilled === 100) return;

            if (!islandTownsMap.has(islandID)) {
                islandTownsMap.set(islandID, { town: town, percentage: percentageFilled });
            } else {
                let existingTown = islandTownsMap.get(islandID);
                if (percentageFilled < existingTown.percentage) {
                    islandTownsMap.set(islandID, { town: town, percentage: percentageFilled });
                }
            }
        });

        // Get the town with the lowest percentage of storage capacity filled from each island
        return Array.from(islandTownsMap.values())
            .map(entry => entry.town.attributes.id)
            .filter(id => id !== undefined); // Ensure we only return valid town IDs
    }

    function getNextCollection() {
        let models = uw.MM.getCollections().FarmTownPlayerRelation[0].models;
        let lootable_at_values = {};
        for (let model of models) {
            let lootable_time = model.attributes.lootable_at;
            if (lootable_at_values[lootable_time]) {
                lootable_at_values[lootable_time] += 1;
            } else {
                lootable_at_values[lootable_time] = 1;
            }
        }
        let max_value = 0;
        let max_lootable_time = 0;
        for (let lootable_time in lootable_at_values) {
            if (lootable_at_values[lootable_time] > max_value) {
                max_value = lootable_at_values[lootable_time];
                max_lootable_time = lootable_time;
            }
        }
        let seconds = max_lootable_time - Math.floor(Date.now() / 1000);
        if (seconds < 0) return 0;
        return seconds * 1000;
    }

    function main() {
        /* Fix time if out of timing */
        let next = getNextCollection();
        if (timer + 2 * delta_time < next) {
            console.log('here');
            timer = next + Math.floor(Math.random() * delta_time);
        }

        /* Claim resources if the timer has passed */
        if (timer < 1) {
            let Polislist = generateList();
            claim(Polislist);
            let rand = Math.floor(Math.random() * delta_time);
            timer = time + rand;
            setTimeout(() => uw.WMap.removeFarmTownLootCooldownIconAndRefreshLootTimers(), 2000);
        }
        /* Update timing */
        const currentTime = Date.now();
        timer -= currentTime - lastTime;
        lastTime = currentTime;
        /* Update the timer */
        var bt = document.getElementById('ptimer');
        if (timer > 0) bt.innerHTML = parseInt(timer / 1000);
        else bt.innerHTML = '0';
    }

    function handleButtonClick() {
        /* If captain is not available, set button yellow and return */
        if (!uw.GameDataPremium.isAdvisorActivated('captain')) {
            uw.$('#btbutton').css(
                'filter',
                'brightness(294%) sepia(100%) hue-rotate(15deg) saturate(1000%) contrast(0.8)',
            );
            var bt = document.getElementById('ptimer');
            bt.innerHTML = '!';
            clearInterval(loop);
            return;
        }
        if (!loop) {
            timer = getNextCollection() + Math.random() * delta_time;
            lastTime = Date.now();
            loop = setInterval(main, 1000);
            uw.$('#btbutton').css(
                'filter',
                'brightness(100%) sepia(100%) hue-rotate(90deg) saturate(1500%) contrast(0.8)',
            );
        } else {
            clearInterval(loop);
            loop = null;
            uw.$('#btbutton').css(
                'filter',
                'brightness(70%) sepia(100%) hue-rotate(-50deg) saturate(1000%) contrast(0.8)',
            );
        }
    }

    // Function to simulate button click randomly after a certain interval
    function simulateButtonClickRandomly() {
        let minDelay1 = 7 * 60 * 60 * 1000; // 1.24 hours in milliseconds
        let maxDelay1 = 10 * 60 * 60 * 1000; // 4.02 hours in milliseconds
        let randomDelay1 = Math.floor(Math.random() * (maxDelay1 - minDelay1 + 1)) + minDelay1;

        setTimeout(() => {
            document.getElementById('btbutton').click();

            // Schedule the second button click after a random interval
            let minDelay2 = 1 * 60 * 1000; // 23 minutes in milliseconds
            let maxDelay2 = 5 * 60 * 1000; // 57 minutes in milliseconds
            let randomDelay2 = Math.floor(Math.random() * (maxDelay2 - minDelay2 + 1)) + minDelay2;

            setTimeout(() => {
                document.getElementById('btbutton').click();
            }, randomDelay2);
        }, randomDelay1);
    }

    setTimeout(function () {
        let btbutton = document.getElementById('btbutton');
        if (btbutton == null) {
            uw.$('.tb_activities, .toolbar_activities').find('.middle').append(buttonHtml);
        }
        if (startOnLogin) handleButtonClick();
        startUpgrading(); // Start upgrading on script load
        scheduleUpgrades(); // Start the scheduled checking
        simulateButtonClickRandomly();
    }, 4000);

    uw.$(document).on('click', '#btbutton', handleButtonClick);

    console.log('[GrepoTweaks-AutoRuralResources] Loaded');
})();
