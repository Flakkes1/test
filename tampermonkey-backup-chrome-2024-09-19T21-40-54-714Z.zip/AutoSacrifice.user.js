// ==UserScript==
// @name         AutoSacrifice
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Anonimo is the biggest cheater ever!
// @author       Anonimo aka sadam
// @match        http://*.grepolis.com/game/*
// @match        https://*.grepolis.com/game/*
// @grant        none
// ==/UserScript==

var uw;
if (typeof unsafeWindow == 'undefined') {
    uw = window;
} else {
    uw = unsafeWindow;
}

let targetTownGroupName = 'Defesa'; // Change this to the desired town group name
let targetTownGroupId = 0;

// This function updates the group ID based on the group name
function updateTownGroup(townGroupName) {
    const townGroup = uw.ITowns.town_groups.models.find(model => model.getName() === townGroupName);
    if (townGroup) {
        targetTownGroupId = townGroup.id;
        console.log(`Town group ID for '${townGroupName}' is: ${targetTownGroupId}`);
    } else {
        console.log(`Town group '${townGroupName}' not found.`);
    }
}

// This function returns an array of town IDs belonging to the selected town group
function getTownsFromGroup(groupId) {
    const townsInGroup = [];
    const towns = uw.MM.getOnlyCollectionByName('Town').models;

    for (const town of towns) {
        let townId = town.id;
        if (uw.ITowns.town_group_towns.hasTown(groupId, townId)) {
            townsInGroup.push(townId);
        }
    }

    return townsInGroup;
}

// Main function that checks conditions and casts the sacrifice
function main() {
    const fury = uw.ITowns.player_gods.attributes.fury;
    const ares_favor = uw.ITowns.player_gods.attributes.ares_favor;

    // Ensure we have a valid town group ID
    if (targetTownGroupId === 0) {
        updateTownGroup(targetTownGroupName);
    }

    if (fury < 5000 && ares_favor >= 100) {
        const towns = getTownsFromGroup(targetTownGroupId);
        if (towns.length > 0) {
            // Select a random town ID from the town group
            const randomIndex = Math.floor(Math.random() * towns.length);
            const selectedTownId = towns[randomIndex];
            console.log(`Casting sacrifice on town ID: ${selectedTownId}`);
            cast_sacrifice(selectedTownId);
        } else {
            console.log('No towns found in the selected town group.');
        }
    }
}

// Function to send the AJAX request to cast sacrifice
function cast_sacrifice(targetId) {
    const data = {
        "model_url": "CastedPowers",
        "action_name": "cast",
        "arguments": {
            "power_id": "ares_sacrifice",
            "target_id": targetId // Use the town ID as the target
        },
        "nl_init": true
    };
    uw.gpAjax.ajaxPost("frontend_bridge", "execute", data, false, {
        success: () => console.log(`Sacrifice cast on town ID: ${targetId}`),
        error: () => console.log(`Failed to cast sacrifice on town ID: ${targetId}`)
    });
}

setInterval(main, 5000);
