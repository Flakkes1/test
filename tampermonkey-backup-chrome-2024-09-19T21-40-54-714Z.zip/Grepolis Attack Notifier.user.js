// ==UserScript==
// @name          Grepolis Attack Notifier
// @description   Send attack notifications to a Discord webhook
// @version       1.2.2
// @author        Anonimo aka Sadam
// @match         http://*.grepolis.com/game/*
// @match         https://*.grepolis.com/game/*
// @grant         none
// ==/UserScript==

var uw;
if (typeof unsafeWindow == 'undefined') uw = window;
else uw = unsafeWindow;

// Replace 'YourName' with the name you want to appear in the notifications
var playerName = 'franks*';

// Keep track of detected attacks
var detectedAttacks = {};
var colonizeShipDuration = null; // Store the colonize ship duration

function main() {
    $.Observer(GameEvents.attack.incoming)
        .subscribe((e, data) => {
            checkForAttack(data);
        });

    function checkForAttack(data) {
        var movementsUnits = uw.MM.getModels().MovementsUnits;
        if (movementsUnits) {
            var movementUnitsArray = Object.values(movementsUnits);
            movementUnitsArray.forEach(movementUnit => {
                if (movementUnit.attributes.type === "attack") {
                    var attackID = movementUnit.cid;
                    if (!detectedAttacks[attackID]) {
                        detectedAttacks[attackID] = true;
                        var attackingTownID = movementUnit.attributes.home_town_id;
                        var targetTownID = movementUnit.attributes.target_town_id;
                        // Calculate the duration of the attack
                        var attackDuration = calculateDuration(movementUnit.attributes.arrival_at);
                        // Print the duration to the console
                        console.log(`Incoming Attack ID: ${attackID}, Duration: ${attackDuration} seconds`);
                        // Fetch additional data for the attack
                        checkForNC(attackingTownID, targetTownID, attackDuration);
                    }
                }
            });
        } else {
            console.error("movementsUnits is not defined.");
        }
    }

    function calculateDuration(arrivalEpoch) {
        var currentTime = Math.floor(Date.now() / 1000); // Get current time in seconds
        var arrivalTime = arrivalEpoch; // Arrival time is already in seconds
        var duration = arrivalTime - currentTime; // Calculate duration in seconds
        return duration > 0 ? duration : 0; // Ensure duration is non-negative
    }

    function checkForNC(attackingTownID, targetTownID, attackDuration) {
        console.log("Calling checkForNC with attackingTownID:", attackingTownID, "and targetTownID:", targetTownID);
        const ncdata = { "id": attackingTownID, "town_id": targetTownID, "nl_init": true };

        uw.gpAjax.ajaxGet("town_info", "support", ncdata);

        // Handle AJAX success to log colonize ship duration and compare
        $(document).ajaxSuccess(function(event, xhr, options) {
            if (options.url.includes('town_info') && options.url.includes('support')) {
                console.log("AJAX request successful for town_info/support.");
                try {
                    const response = JSON.parse(xhr.responseText);
                    console.log("Response received:", response);
                    colonizeShipDuration = response.json.json.units.colonize_ship.duration;
                    console.log(`Colonize ship duration: ${colonizeShipDuration} seconds`);

                    // Compare durations and log result
                    if (colonizeShipDuration) {
                        const lowerBound = 0.7 * colonizeShipDuration;
                        const upperBound = 1.01 * colonizeShipDuration;
                        const ncStatus = (attackDuration >= lowerBound && attackDuration <= upperBound) ? 'Yes' : 'No';
                        console.log(`NC: ${ncStatus}`);

                        // Send notification with NC status
                        sendNotification({
                            arrival_at: Date.now() / 1000 + attackDuration, // Mocking the arrival_at for demonstration
                            home_town_id: attackingTownID,
                            target_town_id: targetTownID
                        }, attackDuration, ncStatus);
                    }
                } catch (error) {
                    console.error("Error parsing response or accessing duration:", error);
                }
            }
        });
    }

    function sendNotification(data, attackDuration, ncStatus) {
        var webhookURL = 'https://discord.com/api/webhooks/1242644672778600530/8e1iUaVQsRvqoKM0YlqJ-iN5kKhogQDPGQDOnrzjc9BfRT0-VL0Wf3pw9rQOVMdEPT0J';
        var arrivalEpoch = data.arrival_at;
        var arrivalTime = new Date(arrivalEpoch * 1000).toLocaleString(); // Convert epoch to milliseconds and then to readable time

        var attackingTownID = data.home_town_id;
        var targetTownID = data.target_town_id;

        var message = `**Name of Player:** ${playerName}\n**Arrival Time:** ${arrivalTime}\n**Attacking Town ID:** ${attackingTownID}\n**Target Town ID:** ${targetTownID}\n**Duration:** ${attackDuration} seconds\n**NC:** ${ncStatus}`;

        var requestData = {
            content: message,
            username: 'Grepolis Attack Notifier'
        };

        // Send HTTP POST request to Discord webhook
        fetch(webhookURL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestData)
        })
        .then(response => {
            if (!response.ok) {
                console.error('Failed to send notification to Discord:', response.statusText);
            }
        })
        .catch(error => {
            console.error('Error sending notification to Discord:', error);
        });
    }
}

setTimeout(main, 1000);