// ==UserScript==
// @name         JANELA
// @namespace    http://tampermonkey.net/
// @version      0.2
// @description  try to take over the world!
// @author       Anonimo aka Sadam
// @match        https://*.grepolis.com/game/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function createInterface() {
        const menu = document.querySelector('.middle ul'); // Select the main menu

        if (!menu) return; // Exit if menu isn't found

        // Create a new list item for the custom window button
        const customWindowItem = document.createElement('li');
        customWindowItem.setAttribute('class', 'gd-custom-window main_menu_item');
        customWindowItem.setAttribute('data-option-id', 'customWindow');

        // Create the button content
        const customWindowButton = document.createElement('a');
        customWindowButton.id = 'customWindowButton';
        customWindowButton.textContent = 'Oh Sadam';
        customWindowButton.style.cursor = 'pointer';
        customWindowButton.addEventListener('click', toggleCustomWindow);

        // Append the button to the new list item
        customWindowItem.appendChild(customWindowButton);

        // Insert the new list item into the menu
        menu.insertBefore(customWindowItem, menu.firstChild);
    }

    function toggleCustomWindow() {
        var customWindow = document.getElementById('customWindow');
        if (!customWindow) {
            createCustomWindow();
        } else {
            // Toggle window visibility
            customWindow.style.display = (customWindow.style.display === 'none') ? 'block' : 'none';
        }
    }

    function createCustomWindow() {
        var customWindow = document.createElement('div');
        customWindow.id = 'customWindow';
        customWindow.style = 'position: fixed; top: 50px; left: 100px; width: 400px; height: 200px; background-color: #FFDDAF; z-index: 10000; border: 1px solid #000; display: block;';
        customWindow.innerHTML = `
            <div class="game_header bold" style="cursor: move; background-color: #2196F3; color: white; padding: 5px;">Custom Window <span style="float: right; cursor: pointer;" onclick="document.getElementById('customWindow').style.display='none';">X</span></div>
            <div style="padding: 10px;">
                <label for="name">Name:</label><br>
                <input type="text" id="name" name="name"><br>
                <label for="email">Email:</label><br>
                <input type="email" id="email" name="email"><br><br>
                <button onclick="alert('Name: ' + document.getElementById('name').value + '\\nEmail: ' + document.getElementById('email').value); document.getElementById('name').value=''; document.getElementById('email').value='';">Submit</button>
            </div>
        `;

        document.body.appendChild(customWindow);
        makeDraggable(customWindow);
    }

    function makeDraggable(elem) {
        var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
        if (document.querySelector(elem.id + " .game_header")) {
            // if present, the header is where you move the DIV from:
            document.querySelector(elem.id + " .game_header").onmousedown = dragMouseDown;
        } else {
            // otherwise, move the DIV from anywhere inside the DIV:
            elem.onmousedown = dragMouseDown;
        }

        function dragMouseDown(e) {
            e = e || window.event;
            e.preventDefault();
            // get the mouse cursor position at startup:
            pos3 = e.clientX;
            pos4 = e.clientY;
            document.onmouseup = closeDragElement;
            // call a function whenever the cursor moves:
            document.onmousemove = elementDrag;
        }

        function elementDrag(e) {
            e = e || window.event;
            e.preventDefault();
            // calculate the new cursor position:
            pos1 = pos3 - e.clientX;
            pos2 = pos4 - e.clientY;
            pos3 = e.clientX;
            pos4 = e.clientY;
            // set the element's new position:
            elem.style.top = (elem.offsetTop - pos2) + "px";
            elem.style.left = (elem.offsetLeft - pos1) + "px";
        }

        function closeDragElement() {
            // stop moving when mouse button is released:
            document.onmouseup = null;
            document.onmousemove = null;
        }
    }

    createInterface();
})();
