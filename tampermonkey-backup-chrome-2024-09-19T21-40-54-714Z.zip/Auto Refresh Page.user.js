// ==UserScript==
// @name         Auto Refresh Page
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Automatically refreshes the page every hour
// @author       Your name
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Function to refresh the page
    function refreshPage() {
        window.location.reload();
    }

    function startScript() {
       // Set the start time (10:00:00 AM)
       const now = new Date();
       const startHour = 20;
       const startMinute = 53;
       const startSecond = 0;
       let delay = ((startHour - now.getHours()) * 60 * 60 +
                    (startMinute - now.getMinutes()) * 60 +
                    (startSecond - now.getSeconds())) * 1000;

    // If the specified time has already passed for today, add 1 day to the delay
    if (delay < 0) {
        delay += 24 * 60 * 60 * 1000;
    }


    setTimeout(refreshPage, delay);
}

// Initial Execution
startScript();
})();