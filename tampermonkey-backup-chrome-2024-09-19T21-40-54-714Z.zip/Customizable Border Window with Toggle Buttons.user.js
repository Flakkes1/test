// ==UserScript==
// @name         Customizable Border Window with Toggle Buttons
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Creates a small window with customizable borders using Tampermonkey, with added toggle buttons to start/stop the scripts
// @author       Your Name
// @match        https://pt101.grepolis.com/game/*
// @match        https://pt101.grepolis.com/game/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Create a container for the window
    const container = document.createElement('div');
    container.id = 'customizableBorderWindow';
    container.style.position = 'fixed';
    container.style.top = '50px'; // Adjust as needed
    container.style.left = '50px'; // Adjust as needed
    container.style.width = '350px'; // Adjust as needed
    container.style.height = '200px'; // Adjust as needed
    container.style.backgroundColor = '#ffffff'; // Background color
    container.style.border = '2px solid #000000'; // Default border color
    container.style.padding = '10px';
    container.style.cursor = 'move'; // Change cursor to indicate draggable
    container.style.zIndex = '9999'; // Set z-index to appear on top

    // Create header
    const header = document.createElement('div');
    header.innerHTML = 'Customizable Border Window';
    header.style.textAlign = 'center';
    header.style.padding = '5px';
    header.style.borderBottom = '1px solid #000000'; // Default border color
    container.appendChild(header);

    // Create left border
    const leftBorder = document.createElement('div');
    leftBorder.style.position = 'absolute';
    leftBorder.style.top = '0';
    leftBorder.style.left = '-2px';
    leftBorder.style.width = '5px'; // Border width
    leftBorder.style.height = '100%';
    leftBorder.style.backgroundColor = '#000000'; // Default border color
    container.appendChild(leftBorder);

    // Create right border
    const rightBorder = document.createElement('div');
    rightBorder.style.position = 'absolute';
    rightBorder.style.top = '0';
    rightBorder.style.right = '-2px';
    rightBorder.style.width = '5px'; // Border width
    rightBorder.style.height = '100%';
    rightBorder.style.backgroundColor = '#000000'; // Default border color
    container.appendChild(rightBorder);

    // Create bottom border
    const bottomBorder = document.createElement('div');
    bottomBorder.style.position = 'absolute';
    bottomBorder.style.bottom = '-2px';
    bottomBorder.style.left = '0';
    bottomBorder.style.width = '100%';
    bottomBorder.style.height = '5px'; // Border width
    bottomBorder.style.backgroundColor = '#000000'; // Default border color
    container.appendChild(bottomBorder);

    // Append container to the body
    document.body.appendChild(container);

    let offsetX, offsetY;
    let isDragging = false;

    // Function to start dragging
    function startDragging(event) {
        isDragging = true;
        offsetX = event.clientX - container.offsetLeft;
        offsetY = event.clientY - container.offsetTop;
    }

    // Function to stop dragging
    function stopDragging() {
        isDragging = false;
    }

    // Function to handle dragging
    function drag(event) {
        if (isDragging) {
            container.style.left = event.clientX - offsetX + 'px';
            container.style.top = event.clientY - offsetY + 'px';
        }
    }

    // Event listeners for mouse events
    header.addEventListener('mousedown', startDragging);
    document.addEventListener('mouseup', stopDragging);
    document.addEventListener('mousemove', drag);

    // Function to change border color
    function changeBorderColor(color) {
        container.style.border = `2px solid ${color}`;
        header.style.borderBottom = `1px solid ${color}`;
        leftBorder.style.backgroundColor = color;
        rightBorder.style.backgroundColor = color;
        bottomBorder.style.backgroundColor = color;
    }

    // Variable to track whether each script is running
    let isScript1Running = false;

    // Store interval id for script1
    let intervalId1;

    // Function to toggle Script 1 on/off
    function toggleScript1() {
        if (isScript1Running) {
            clearInterval(intervalId1);
            isScript1Running = false;
        } else {
            clearInterval(intervalId1); // Stop the script if it's already running
            isScript1Running = false;
            script1(); // Call script1 to start it
            intervalId1 = setInterval(script1, 20000); // Interval for script1
            isScript1Running = true;
        }
    }

    // Create the toggle button for Script 1
    const toggleButton1 = createToggleButton('Script 1');

    // Append the button to the container
    container.appendChild(toggleButton1);

    // Function to create a toggle button
    function createToggleButton(scriptName) {
        const button = document.createElement('button');
        button.textContent = scriptName;
        button.style.backgroundColor = '#4CAF50'; // Green color
        button.style.color = '#ffffff';
        button.style.padding = '10px';
        button.style.border = 'none';
        button.style.cursor = 'pointer';
        button.style.marginTop = '10px'; // Adjust as needed
        button.addEventListener('click', function() {
            switch (scriptName) {
                case 'Script 1':
                    toggleScript1();
                    break;
                // Add more cases for additional scripts
            }
        });
        return button;
    }
})();

// Script 1
function script1() {
    const timer = (ms) => new Promise((res) => setTimeout(res, ms));

setTimeout(async() => {
    await main();

    setInterval(async() => {
        await main()
    },20000);
}, 7000);


let req = {slinger:1,archer:1,town_guard:1,
           hoplite:4,meteorology:4,
           espionage:7,booty:7,pottery:7,
           architecture:10,rider:10,instructor:10,
           bireme:13,building_crane:13,shipwright:13,colonize_ship:13,
           chariot:16,attack_ship:16,conscription:16,
           demolition_ship:19,catapult:19,cryptography:19,democracy:19,
           small_transporter:22,plow:22,berth:22,
           trireme:25,phalanx:25,breach:25,mathematics:25,
           ram:28,cartography:28,take_over:28,
           stone_storm:31,temple_looting:31,divine_selection:31,
           combat_experience:34,strong_wine:34,set_sail:34
          }



let model = {slinger:false,
             archer:false,
             town_guard:false,
             hoplite:false,
             meteorology:false,
             espionage:false,
             booty:true,
             pottery:true,
             rider:false,
             architecture:true,
             instructor:false,
             bireme:false,
             building_crane:true,
             shipwright:true,
             colonize_ship:true,
             chariot:false,
             attack_ship:false,
             conscription:false,
             demolition_ship:false,
             catapult:false,
             cryptography:false,
             democracy:false,
             small_transporter:false,
             plow:true,
             berth:false,
             trireme:false,
             phalanx:false,
             breach:false,
             mathematics:true,
             ram:false,
             cartography:true,
             take_over:false,
             stone_storm:false,
             temple_looting:false,
             divine_selection:false,
             combat_experience:true,
             strong_wine:true,
             set_sail:true,
             diplomacy:false
            }


async function main(){
    let towns = uw.MM.getOnlyCollectionByName('Town').models; //saca todas as cidades7
    console.log(towns);
    for (const town of towns){ //percorre as cidades -> town fica com imensas merdas (mete ITowns.getCurrentTown() na consola para ver
        let townId = town.id;
        const researches = town.getResearches().attributes;
        const academyLvl = town.getBuildings().attributes.academy;
        for (const [id, value] of Object.entries(researches)){
            if (id == 'diplomacy' || id == 'id') continue;
            if (model[id] != value && academyLvl >= req[id] && model[id]){

                let data = {};
                data.model_url = "ResearchOrder";
                data.action_name = "research";
                data.arguments = {id};
                data.town_id = townId;
                data.nl_init = true;
                uw.gpAjax.ajaxPost('frontend_bridge', 'execute', data);
                await timer(1500);
            }

        }


    }

}
    main();
}
