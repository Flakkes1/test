// ==UserScript==
// @name         Resource Balancer for Grepolis
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Automatically balance resources between cities to ensure minimum levels are maintained
// @author       Anonimo aka Sadam
// @match        http://*.grepolis.com/game/*
// @match        https://*.grepolis.com/game/*
// @icon         https://www.google.com/s2/favicons?domain=grepolis.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    var uw = typeof unsafeWindow !== 'undefined' ? unsafeWindow : window;

    // Delays a function execution by ms milliseconds
    function timer(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async function checkMovements() {
        const data = { "nl_innit": true };
        uw.gpAjax.ajaxGet("town_overviews", "trade_overview", data);

        $(document).ajaxSuccess(function(event, xhr, options) {
            // Check if the AJAX request is for retrieving town_overviews/trade_overview
            if (options.url.includes('town_overviews') && options.url.includes('trade_overview')) {
                // Parse the response text to JSON
                const response = JSON.parse(xhr.responseText);
                // Check if the response contains movements
                const hasNoMovements = !response.json || !response.json.movements || response.json.movements.length === 0;
                console.log(hasNoMovements);

                // If there are no movements, start the resource balancing script
                if (hasNoMovements) {
                    main();
                }
            }
        });
    }


    // Main logic of your script that will be executed after all trades have arrived
    async function main() {
        console.log("Resource balancing script activated.");

        const { models: towns } = uw.MM.getOnlyCollectionByName('Town');

        // Initial population of surplus and deficit towns
        let surplusTowns = [];
        let deficitTowns = [];

        for (const town of towns) {
            try {
                updateTownLists(town, surplusTowns, deficitTowns);
            } catch (error) {
                console.error(`Error while checking town ${town.attributes.id}:`, error);
            }
        }

        console.log("Surplus Towns:", surplusTowns.map(t => t.id).join(', '));
        console.log("Deficit Towns:", deficitTowns.map(t => t.id).join(', '));

        // Balance resources between surplus and deficit towns
        for (const deficitTown of deficitTowns) {
            let { id: deficitTownId, wood: deficitWood, stone: deficitStone, iron: deficitIron } = deficitTown;

            while (true) {
                let resourceTransferred = false;

                for (const surplusTown of surplusTowns) {
                    let { id: surplusTownId, wood: surplusWood, stone: surplusStone, iron: surplusIron, tradeCapacity: surplusTradeCapacity } = surplusTown;

                    if (surplusTradeCapacity <= 100) continue;

                    let maxWoodToSend = Math.min(surplusTradeCapacity, 15000 - deficitWood, surplusWood - 15000);
                    let maxStoneToSend = Math.min(surplusTradeCapacity, 18000 - deficitStone, surplusStone - 18000);
                    let maxIronToSend = Math.min(surplusTradeCapacity, 15000 - deficitIron, surplusIron - 15000);

                    let woodToSend = Math.max(0, maxWoodToSend);
                    let stoneToSend = Math.max(0, maxStoneToSend);
                    let ironToSend = Math.max(0, maxIronToSend);

                    if (woodToSend > 0 || stoneToSend > 0 || ironToSend > 0) {
                        let totalResourcesToSend = woodToSend + stoneToSend + ironToSend;

                        // Ensure the total amount of resources being sent does not exceed the trade capacity
                        if (totalResourcesToSend > surplusTradeCapacity) {
                            let scale = surplusTradeCapacity / totalResourcesToSend;
                            woodToSend = Math.floor(woodToSend * scale);
                            stoneToSend = Math.floor(stoneToSend * scale);
                            ironToSend = Math.floor(ironToSend * scale);
                        }

                        let data = {
                            id: deficitTownId,
                            town_id: surplusTownId,
                            wood: Math.round(woodToSend),
                            stone: Math.round(stoneToSend),
                            iron: Math.round(ironToSend),
                            nl_init: true,
                            type: 'trade'
                        };

                        console.log(`Sending resources from town ${surplusTownId} to town ${deficitTownId}: Wood=${woodToSend}, Stone=${stoneToSend}, Iron=${ironToSend}`);

                        await timer(1000); // Delay between each trade

                        await uw.gpAjax.ajaxPost('town_info', 'trade', data);
                        console.log(`Sent resources from town ${surplusTownId} to town ${deficitTownId}: Wood=${woodToSend}, Stone=${stoneToSend}, Iron=${ironToSend}`);

                        // Update deficit town resources
                        deficitWood += woodToSend;
                        deficitStone += stoneToSend;
                        deficitIron += ironToSend;

                        // Update surplus town resources and trade capacity
                        surplusTown.wood -= woodToSend;
                        surplusTown.stone -= stoneToSend;
                        surplusTown.iron -= ironToSend;
                        surplusTown.tradeCapacity -= (woodToSend + stoneToSend + ironToSend);

                        resourceTransferred = true;
                        break;
                    }
                }

                if (!resourceTransferred) break;
            }
        }
    }

    // Update the lists of surplus and deficit towns
    function updateTownLists(town, surplusTowns, deficitTowns) {
        const { id } = town.attributes;
        const storageCapacity = town.attributes.storage;

        // Check if the storage capacity is less than 18000 for any resource
        if (storageCapacity < 18000) {
            return; // Skip this town if storage capacity is less than 18000
        }
        const resources = uw.ITowns.getTown(id).resources();
        const { wood, stone, iron } = resources;
        const tradeCapacity = town.attributes.available_trade_capacity;

        const woodSpare = Math.max(wood - 15000, 0);
        const stoneSpare = Math.max(stone - 18000, 0);
        const ironSpare = Math.max(iron - 15000, 0);

        const woodNeeded = Math.max(0, 15000 - wood);
        const stoneNeeded = Math.max(0, 18000 - stone);
        const ironNeeded = Math.max(0, 15000 - iron);

        if (woodSpare > 100 && stoneSpare > 100 && ironSpare > 100) {
            surplusTowns.push({ id, wood, stone, iron, tradeCapacity, woodSpare, stoneSpare, ironSpare });
            surplusTowns = sortSurplusTowns(surplusTowns);
        } else {
            deficitTowns.push({ id, wood, stone, iron, woodNeeded, stoneNeeded, ironNeeded, tradeCapacity });
        }
    }

    // Sort surplus towns by their available trade capacity in descending order
    function sortSurplusTowns(surplusTowns) {
        return surplusTowns.sort((a, b) => b.tradeCapacity - a.tradeCapacity);
    }

    // Start the script
    setTimeout(checkMovements, 5000);

    setInterval(checkMovements, 30 * 60 * 1000);
})();

