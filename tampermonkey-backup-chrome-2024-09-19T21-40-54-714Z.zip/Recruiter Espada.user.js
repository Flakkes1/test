// ==UserScript==
// @name         Recruiter Espada
// @version      2.1.3
// @description  Automatic event
// @author       Anonimo aka Sadam
// @match        http://*.grepolis.com/game/*
// @match        https://*.grepolis.com/game/*
// ==/UserScript==

var uw;
if (typeof unsafeWindow == 'undefined') {
    uw = window;
} else {
    uw = unsafeWindow;
}

function main() {
    const data = {
        "unit_id": "sword",
        "amount": 1,
        "nl_init": true
    };

    uw.gpAjax.ajaxPost("building_barracks", "build", data);
    setTimeout(() => {cancelar();}, 200);
}



function cancelar() {
    const flecha = {
        "model_url":"UnitOrder",
        "action_name":"cancelOrder",
        "captcha":null,
        "arguments":{"unit_type":"ground"},
        "nl_init": true
    };

    uw.gpAjax.ajaxPost("frontend_bridge", "execute", flecha);
}

// Run the script when the page loads
window.addEventListener('load', function() {
    main();
});

setInterval(main, 1000);