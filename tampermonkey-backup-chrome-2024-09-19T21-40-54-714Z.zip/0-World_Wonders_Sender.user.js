// ==UserScript==
// @name         0-World_Wonders_Sender
// @author       anonimous
// @description  World_Wonders_Sender
// @include      http://*.grepolis.com/game/*
// @include      https://*.grepolis.com/game/*
// ==/UserScript==

const timer = (ms) => new Promise((res) => setTimeout(res, ms));
let island_x_number = 516;
let island_y_number = 490;
let finished = false;
//wonders?town_id=2276&action=index&h=32486c13f03736f428c59cefecae80f978624a34&json=%7B"island_x"%3A516%2C"island_y"%3A490%2C"town_id"%3A2276%2C"nl_init"%3Atrue%7D&_=1687793878768
var uw = unsafeWindow || window,
    $ = uw.jQuery;
$.Observer(uw.GameEvents.game.load).subscribe(() => {
    if(GameDataWorldWonders.hasAgeOfWonderStarted()){
        setTimeout(async() => {

            await main()
        }, 1000);
        setInterval(async() => {

            await main()
        }, 130000);
    }
  });




async function main(){
    if (finished === true){
        return;
    }

    const polisList = [];
    let wood_amount = 0;
    let stone_amount = 0;
    let iron_amount = 0;
    const { models: towns } = uw.MM.getOnlyCollectionByName('Town');
    check_state(towns[0].id);
    for (const town of towns) {
        let {available_trade_capacity, id } = town.attributes;
        if( available_trade_capacity === 0) continue;
        const aux = uw.ITowns.getTown(id);
        const { wood, stone, iron, storage } = aux.resources();
        let total = wood + stone + iron;
        if( total < 100) continue;
        if(available_trade_capacity/3 > wood){
            wood_amount = wood;
        }
        else{
            wood_amount = available_trade_capacity/3;
        }
        if(available_trade_capacity/3 > stone){
            stone_amount = stone;
        }
        else{
            stone_amount = available_trade_capacity/3;
        }
        if(available_trade_capacity/3 > iron){
            iron_amount = iron;
        }
        else{
            iron_amount = available_trade_capacity/3;
        }
        send_resources(wood_amount,stone_amount,iron_amount,id);
        await timer(750);

    }

}

function send_resources(wood_amount,stone_amount,iron_amount,id){

    var data = {"wood":wood_amount,"stone":stone_amount,"iron":iron_amount,"island_x": island_x_number,"island_y": island_y_number,"town_id":id,"nl_init":true};

    let auxxxx = uw.gpAjax.ajaxPost('wonders', 'send_resources', data);


}

async function check_state(id){

    var data = {"island_x":island_x_number,"island_y":island_y_number,"town_id":id,"nl_init":true};

    let auxxxx = uw.gpAjax.ajaxGet('wonders', 'index', data);

    await timer(1000);
    let final = JSON.parse(auxxxx.responseText);
    if( final.json.data.sum_ressources_on_the_way.wood + final.json.data.wonder_res.wood > final.json.data.needed_resources.wood && final.json.data.sum_ressources_on_the_way.stone + final.json.data.wonder_res.stone > final.json.data.needed_resources.stone && final.json.data.sum_ressources_on_the_way.iron + final.json.data.wonder_res.iron > final.json.data.needed_resources.iron){
        finished = true;
    }


}

//final.json.data.stage_completed_at != null
var data = {"island_x":505,"island_y":476,"town_id":16063,"nl_init":true}
