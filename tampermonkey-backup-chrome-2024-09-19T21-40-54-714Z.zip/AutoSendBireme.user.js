// ==UserScript==
// @name         AutoSendBireme
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @include      http://pt101.grepolis.com/game/*
// @include      https://pt101.grepolis.com/game/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=grepolis.com
// @grant        none
// ==/UserScript==

const timer = (ms) => new Promise((res) => setTimeout(res, ms));

let arrival_id = 3791;
$.Observer(uw.GameEvents.game.load).subscribe(() => {
    setTimeout(async () => {
        await main();
    }, 1000);
});

async function main() {
    let arrival_id = 3791;
    const { models: towns } = uw.MM.getOnlyCollectionByName('Town');

    let repeat = true;

    while (repeat) {
        repeat = false; // Assume no more than 20 bireme until proven otherwise

        for (const town of towns) {
            const { id } = town.attributes;
            let data = {};
            await timer(1000);
            if (uw.ITowns.towns[id].units().bireme == null) continue;
            if (uw.ITowns.towns[id].units().bireme < 20) continue; // Skip if less than 20 bireme
            repeat = true; // Set repeat flag to true if there's more than 20 bireme
            data.bireme = 20;
            data.id = arrival_id;
            data.type = "attack";
            data.town_id = id; //uw.ITowns.getCurrentTown().id;
            data.nl_init = true;
            uw.gpAjax.ajaxPost('town_info', 'send_units', data);
        }
    }
}