// ==UserScript==
// @name         COMPRARRRRRRRRR
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Buys resources from the market
// @author       Anonimo aka Sadam
// @match        https://*.grepolis.com/game/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=grepolis.com
// @grant        none
// ==/UserScript==


var uw;
if (typeof unsafeWindow == 'undefined') {
	uw = window;
} else {
	uw = unsafeWindow;
}
(function() {
    'use strict';

    let isWaitingForResponse = false;

    $(document).ajaxSuccess(function(event, xhr, options) {
        if (options.url.includes('frontend_bridge') && options.data.includes('requestOffer')) {
            const response = JSON.parse(xhr.responseText);
            if (response && response.json && response.json.result === "success") {
                const mac = response.json.mac;
                const gold = response.json.offer.gold;
                const iron = response.json.offer.resource_amount;
                confirmOffer(mac, gold, iron);
                isWaitingForResponse = false; // Reset the flag after confirming the offer
            }
        }
    });

    async function requestOffer() {
        if(isWaitingForResponse) return; // Check if we're already waiting for a response to avoid overlapping calls
        isWaitingForResponse = true; // Set the flag when making a new request
        const y = 1000
        const x = Math.round(y * 0.016);
        const data = {
            "model_url": "PremiumExchange",
            "action_name": "requestOffer",
            "arguments": {
                "type": "sell",
                "gold": x,
                "iron": y
            },
            "nl_init": true
        };

        uw.gpAjax.ajaxPost('frontend_bridge', 'execute', data);
    }

    async function confirmOffer(mac, gold, iron) {
        const data = {
            "model_url": "PremiumExchange",
            "action_name": "confirmOffer",
            "arguments": {
                "type": "sell",
                "gold": gold,
                "mac": mac,
                "offer_source": "main",
                "iron": iron
            },
            "nl_init": true
        };

        uw.gpAjax.ajaxPost('frontend_bridge', 'execute', data);
    }

    setInterval(requestOffer, 1000); // Attempt to request an offer every second
})();