// ==UserScript==
// @name ALERTA OURO
// @description Verifica se há ouro a cada 10s e avisa
// @version 1.1.2
// @match https://*.grepolis.com/game/*
// ==/UserScript==

(function() {
    'use strict';

    const threshold = 500;
    const townIds = [2779, 11371, 1573, 14566]; // Replace with actual town IDs
    const townNames = { 2779: '44', 11371: '45', 1573: '54', 14566: '55' }; // Add town ID to its respective ocean

    // Fetch market data from the server for a specific town
    async function getMarket(town_id) {
        try {
            let data = { "model_url": "PremiumExchange", "action_name": "read", "town_id": town_id };
            let req = await gpAjax.ajaxGet("frontend_bridge", "execute", data);
            return JSON.parse(req);
        } catch (error) {
            console.error(`Failed to fetch market data for town_id ${town_id}:`, error);
            return null;
        }
    }

    // Check if the resource is below the capacity threshold
    function isResourceMissing(res) {
        return res.stock + threshold < res.capacity;
    }

    // Add notification div to the webpage
    function addNotification() {
        let body = document.getElementsByTagName("body")[0];
        let div = document.createElement("div");
        div.id = "marketNotification";
        div.className = "notification";
        div.innerHTML = `<h3></h3>`;
        div.style.cursor = "pointer";
        body.appendChild(div);
        div.addEventListener('click', function() {
            hideNotification();
            stopNotificationSound();
        });
        return div;
    }

    // Display the notification with a specific message
    function displayNotification(message = '') {
        notification.innerHTML = `<h3>${message}</h3>`;
        notification.style.bottom = "20px";
        notification.style.visibility = "visible";
        notification.style.opacity = "1";
        notification.style.transition = "bottom 0.7s ease-out";
    }

    // Hide the notification
    function hideNotification() {
        notification.style.visibility = "hidden";
        notification.style.opacity = "0";
        notification.style.transition = "visibility 0s 2s, opacity 2s linear";
        setTimeout(() => {
            notification.style.bottom = "150px";
        }, 2000);
    }

    // Play notification sound
    function playNotificationSound() {
        audio.play();
    }

    // Stop notification sound
    function stopNotificationSound() {
        audio.pause();
        audio.currentTime = 0;
    }

    // Main function to check market status and trigger notifications
    async function main() {
        let market = false;
        let messages = []; // Array to store all notification messages

        for (let i = 0; i < townIds.length; i++) {
            await new Promise(resolve => setTimeout(resolve, 1000)); // 1-second delay
            let data = await getMarket(townIds[i]);

            if (data) {
                let townMessage = '';

                if (isResourceMissing(data.json.iron) ||
                    isResourceMissing(data.json.stone) ||
                    isResourceMissing(data.json.wood)) {

                    townMessage = `Market not full in Oc. ${townNames[townIds[i]]}`;
                    messages.push(townMessage); // Store each town's message

                    market = true;
                }
            }
        }

        if (!market && lastMarket) hideNotification();
        if (market) {
            playNotificationSound();
            displayNotification(messages.join('<br>')); // Join all messages with line breaks
        }

        lastMarket = market;
    }

    let lastMarket = false;
    const notification = addNotification();
    const audio = new Audio("https://lasonotheque.org/UPLOAD/mp3/0962.mp3");
    audio.preload = 'auto'; // Preload audio
    let loop = setInterval(main, 10000);

    // Add CSS styles
    const styles = `
        .notification {
            position: absolute;
            bottom: 150px;
            right: 20px;
            border-radius: 25px;
            z-index: 100;
            background: #48f500;
            width: 200px;
            visibility: hidden;
            opacity: 1;
            transition: visibility 0s 2s, opacity 2s linear, bottom 0.7s ease-out;
        }
    `;
    let styleSheet = document.createElement("style");
    styleSheet.type = "text/css";
    styleSheet.innerText = styles;
    document.head.appendChild(styleSheet);

})();
