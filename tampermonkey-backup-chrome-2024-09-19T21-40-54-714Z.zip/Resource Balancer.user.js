// ==UserScript==
// @name         Resource Balancer
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Automatically balance resources between cities to ensure minimum levels are maintained
// @author       You
// @match        https://*.grepolis.com/game/*
// @icon         https://www.google.com/s2/favicons?domain=grepolis.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    var uw = typeof unsafeWindow !== 'undefined' ? unsafeWindow : window;

    async function timer(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async function main() {
        const { models: towns } = uw.MM.getOnlyCollectionByName('Town');

        // Find surplus and deficit towns
        let surplusTowns = [];
        let deficitTowns = [];

        for (const town of towns) {
            const { id } = town.attributes;

            try {
                const resources = uw.ITowns.getTown(id).resources();
                const { wood, stone, iron } = resources;
                console.log(`Checking town ${id}: Wood=${wood}, Stone=${stone}, Iron=${iron}`);

                if (wood > 15000 && stone > 18000 && iron > 15000) {
                    surplusTowns.push(id);
                } else {
                    deficitTowns.push(id);
                }
            } catch (error) {
                console.error(`Error while checking town ${id}:`, error);
            }
        }

        console.log("Surplus Towns:", surplusTowns.join(', '));
        console.log("Deficit Towns:", deficitTowns.join(', '));

        // Balance resources between surplus and deficit towns
        for (const deficitTownId of deficitTowns) {
            const deficitTown = uw.ITowns.getTown(deficitTownId);
            const { wood, stone, iron } = deficitTown.resources();
            let woodNeeded = Math.max(0, 15000 - wood);
            let stoneNeeded = Math.max(0, 18000 - stone);
            let ironNeeded = Math.max(0, 15000 - iron);

            for (const surplusTownId of surplusTowns) {
                const surplusTown = uw.ITowns.getTown(surplusTownId);
                const { wood: surplusWood, stone: surplusStone, iron: surplusIron } = surplusTown.resources();
                let woodAvailable = Math.max(0, surplusWood - 15000);
                let stoneAvailable = Math.max(0, surplusStone - 18000);
                let ironAvailable = Math.max(0, surplusIron - 15000);

                console.log(`Wood Available in town ${surplusTownId}: ${woodAvailable}`);
                console.log(`Stone Available in town ${surplusTownId}: ${stoneAvailable}`);
                console.log(`Iron Available in town ${surplusTownId}: ${ironAvailable}`);

                let woodToSend = Math.ceil(Math.min(woodNeeded, woodAvailable));
                let stoneToSend = Math.ceil(Math.min(stoneNeeded, stoneAvailable));
                let ironToSend = Math.ceil(Math.min(ironNeeded, ironAvailable));

                console.log(`Wood to Send from town ${surplusTownId}: ${woodToSend}`);
                console.log(`Stone to Send from town ${surplusTownId}: ${stoneToSend}`);
                console.log(`Iron to Send from town ${surplusTownId}: ${ironToSend}`);

                // Check if any resource to send is negative
                if (woodToSend <= 0 && stoneToSend <= 0 && ironToSend <= 0) {
                    console.error(`No resources to send from town ${surplusTownId}`);
                    continue; // Move to the next surplus town
                }

                let data = {
                    id: deficitTownId,
                    town_id: surplusTownId,
                    wood: Math.round(woodToSend),
                    stone: Math.round(stoneToSend),
                    iron: Math.round(ironToSend),
                    nl_init: true,
                    type: 'trade'
                };

                console.log("Sending resources data:", data);

                await timer(1000); // Delay between each trade

                await uw.gpAjax.ajaxPost('town_info', 'trade', data);
                console.log(`Sending resources from town ${surplusTownId} to town ${deficitTownId}:`, data);

                // Update remaining needs after trade
                woodNeeded -= woodToSend;
                stoneNeeded -= stoneToSend;
                ironNeeded -= ironToSend;

                // Exit loop if all needs are met
                if (woodNeeded <= 0 && stoneNeeded <= 0 && ironNeeded <= 0) break;
            }
        }
    }

    setTimeout(main, 5000); // Wait 5 seconds after page load to run the script
})();
