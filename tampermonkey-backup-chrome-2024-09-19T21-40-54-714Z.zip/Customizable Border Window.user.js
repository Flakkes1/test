// ==UserScript==
// @name         Customizable Border Window
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Creates a small window with customizable borders using Tampermonkey
// @author       Your Name
// @match        https://pt101.grepolis.com/game/*
// @match        https://pt101.grepolis.com/game/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Create a container for the window
    const container = document.createElement('div');
    container.style.position = 'fixed';
    container.style.top = '50px'; // Adjust as needed
    container.style.left = '50px'; // Adjust as needed
    container.style.width = '350px'; // Adjust as needed
    container.style.height = '200px'; // Adjust as needed
    container.style.backgroundColor = '#ffffff'; // Background color
    container.style.border = '2px solid #000000'; // Default border color
    container.style.padding = '10px';
    container.style.cursor = 'move'; // Change cursor to indicate draggable
    container.style.zIndex = '9999'; // Set z-index to appear on top

    // Create header
    const header = document.createElement('div');
    header.innerHTML = 'Customizable Border Window';
    header.style.textAlign = 'center';
    header.style.padding = '5px';
    header.style.borderBottom = '1px solid #000000'; // Default border color

    // Create left border
    const leftBorder = document.createElement('div');
    leftBorder.style.position = 'absolute';
    leftBorder.style.top = '0';
    leftBorder.style.left = '-2px';
    leftBorder.style.width = '5px'; // Border width
    leftBorder.style.height = '100%';
    leftBorder.style.backgroundColor = '#000000'; // Default border color

    // Create right border
    const rightBorder = document.createElement('div');
    rightBorder.style.position = 'absolute';
    rightBorder.style.top = '0';
    rightBorder.style.right = '-2px';
    rightBorder.style.width = '5px'; // Border width
    rightBorder.style.height = '100%';
    rightBorder.style.backgroundColor = '#000000'; // Default border color

    // Create bottom border
    const bottomBorder = document.createElement('div');
    bottomBorder.style.position = 'absolute';
    bottomBorder.style.bottom = '-2px';
    bottomBorder.style.left = '0';
    bottomBorder.style.width = '100%';
    bottomBorder.style.height = '5px'; // Border width
    bottomBorder.style.backgroundColor = '#000000'; // Default border color

    // Append elements to the container
    container.appendChild(header);
    container.appendChild(leftBorder);
    container.appendChild(rightBorder);
    container.appendChild(bottomBorder);

    // Append container to the body
    document.body.appendChild(container);

    let offsetX, offsetY;
    let isDragging = false;

    // Function to start dragging
    function startDragging(event) {
        isDragging = true;
        offsetX = event.clientX - container.offsetLeft;
        offsetY = event.clientY - container.offsetTop;
    }

    // Function to stop dragging
    function stopDragging() {
        isDragging = false;
    }

    // Function to handle dragging
    function drag(event) {
        if (isDragging) {
            container.style.left = event.clientX - offsetX + 'px';
            container.style.top = event.clientY - offsetY + 'px';
        }
    }

    // Event listeners for mouse events
    header.addEventListener('mousedown', startDragging);
    document.addEventListener('mouseup', stopDragging);
    document.addEventListener('mousemove', drag);

    // Function to change border color
    function changeBorderColor(color) {
        container.style.border = `2px solid ${color}`;
        header.style.borderBottom = `1px solid ${color}`;
        leftBorder.style.backgroundColor = color;
        rightBorder.style.backgroundColor = color;
        bottomBorder.style.backgroundColor = color;
    }

    // Example of changing border color (you can call this function anywhere in your script)
    //changeBorderColor('#ff0000'); // Change border color to red
})();