// ==UserScript==
// @name         DailyBonus
// @version      0.1
// @description  Automatic event
// @author       Anonimo aka Sadam
// @match        http://*.grepolis.com/game/*
// @match        https://*.grepolis.com/game/*
// ==/UserScript==

var uw;
if (typeof unsafeWindow == 'undefined') {
    uw = window;
} else {
    uw = unsafeWindow;
}

function main() {
        const data = {"model_url":"DailyLoginBonus","action_name":"accept","captcha":null,"arguments":{"option":1},"nl_init":true};
        uw.gpAjax.ajaxPost('frontend_bridge', 'execute', data);
    }


setTimeout(main, 7000);
